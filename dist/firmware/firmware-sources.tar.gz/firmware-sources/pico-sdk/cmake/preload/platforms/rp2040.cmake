set(PICO_DEFAULT_GCC_COMPILER "pico_arm_cortex_m0plus_gcc")
set(PICO_DEFAULT_CLANG_COMPILER "pico_arm_cortex_m0plus_clang")
set(PICO_DEFAULT_COMPILER ${PICO_DEFAULT_GCC_COMPILER})
set(PICO_CHIP rp2040)
