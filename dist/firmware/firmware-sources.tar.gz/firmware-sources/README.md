# LA_RP2040 集成说明 · v0.3

> **两种板型。** V2（电平转换、16 Pin、官方 Debug Probe 管脚）见下面「LA_RP2040 V2」一节；本文其余部分描述的是 V1（3.3 V 直连、12 Pin）。两种板型的固件不能混用，Agent 按 USB 产品名自动区分。


本版本依据用户上传的 `LA_RP2040.zip` 中 KiCad PCB / 原理图的网络连接适配，保留 CH347 的所有原有功能。三份 UF2 已交叉编译；没有接入实板，USB 枚举、GPIO 电平、最高速度和电压精度仍须验收。

## 能做什么

| 配置 | Agent 已实现 | 限制 |
|---|---|---|
| CMSIS-DAP + UART | OpenOCD SWD、ELF/HEX 烧录校验、GDB、暂停/继续/单步/复位、寄存器/内存、CDC 串口收发 | 本版 SWD 100 kHz–1 MHz；上游 debugprobe 未实现 JTAG / SWO，不能用它运行 openFPGALoader |
| SUMP8 逻辑分析 | 同步 8 通道、单通道边沿/电平触发、采集超时/取消、波形缩放/平移、A/B 游标、CSV/VCD/PulseView `.sr` 导出 | 100 kSa/s–20 MSa/s，最多 100000 点，无前触发；非持续流；未承诺实板可用最高速率 |
| ADC12 数字示波器 | 从 ADC0/1/2 选单路、12 bit 原始码、ADC + DMA 定长采集、波形缩放/平移、时间/电压游标、Vmin/Vmax/Vpp/均值/RMS、CSV/原始 u16le 导出 | 10–500 kSa/s，最多 32768 点，未校准，无连续流和硬件模拟触发；500 kSa/s 不等于 500 kHz 模拟带宽 |

三种配置通过 BOOTSEL 刷写互相替换，不能同时运行。逻辑/ADC 不需要 OpenOCD；SWD 需要支持 `cmsis-dap` bulk 后端的 OpenOCD。现有 FPGA / SPI Flash / XVC 等任务继续使用 CH347。导出的 `.sr` 供 PulseView 进行离线协议解码；本版没有内置 UART/I²C/SPI 逻辑解码器。

## LA_RP2040 V2

硬件工程在 [`hardware/la-rp2040-v2/`](../hardware/la-rp2040-v2/README.md)。**没有打样，以下固件只做了交叉编译和主机侧测试，没有在实板上运行过。**

| J2 脚号 | 网络 | 调试固件 | 逻辑分析固件 | 示波器固件 |
|---|---|---|---|---|
| 1 | VREF | 目标参考电压 | 目标参考电压 | — |
| 3 | IO0 · GP12 | SWCLK | D0 | — |
| 5 | IO1 · GP14 出 / GP13 入 | SWDIO | D1 | — |
| 7 | IO2 · GP20 | 目标 nRESET | D2 | — |
| 9 | IO3 · GP4 | UART TX | D3 | — |
| 11 | IO4 · GP5 | UART RX | D4 | — |
| 4 / 6 / 8 | IO5–IO7 · GP23–GP25 | — | D5–D7 | — |
| 13 / 12 / 14 | A0 / A1 / A2 · GP26–GP28 | — | — | ADC0 / ADC1 / ADC2 |
| 2 / 10 / 15 | GND | 共地 | 共地 | 共地 |
| 16 | +5V | 约 4.6 V 输出 | 约 4.6 V 输出 | 约 4.6 V 输出 |

IO0–IO7 经 74LVC1T45 电平转换，目标侧电平跟随 VREF（1.65–5.5 V）；开关拨到 EXT 时 VREF 接目标 VCC，拨到 INT 时由调试器提供约 3.0 V。A0–A2 不经过电平转换，量程 0–3.3 V。

| 固件 | USB 产品名 | 与 V1 的差别 |
|---|---|---|
| `la-rp2040-v2-dap.uf2` | `LA-RP2040 V2 CMSIS-DAP` | 使用上游 Debug Probe 板级配置（GP12/13/14、UART GP4/5、五个状态灯）；增加 nRESET：GP20 经电平转换输出，方向线 GP21 只在拉低复位时置高，释放后由目标侧上拉。SWDIO 为 470 Ω 强上拉方式，见硬件 README。 |
| `la-rp2040-v2-sump8.uf2` | `LA-RP2040 V2 SUMP8 v1` | 8 路输入不在连续管脚上：PIO 一次采样 GP4–GP25 共 22 位，每个采样存 32 位，读回时重排为 D0–D7。**深度 50000 点**（V1 为 100000）。启动时把 DIR0 / DIR1 / DIR3（GP18 / GP19 / GP22）拉低，使 8 路全部为输入。状态灯为 GP16。 |
| `la-rp2040-v2-adc12.uf2` | `LA-RP2040 V2 ADC12 v1` | 协议和 ADC 管脚不变，状态灯改为 GP16。 |

官方 `debugprobe.uf2` 也可以直接刷到 V2 上（产品名 `Debug Probe (CMSIS-DAP)`，没有 nRESET）；Agent 会把它当作 V2 管脚处理，并提示未确认是本板固件。V2 的 Flash 为 2 MiB（W25Q16）。

构建：`python firmware/build.py --work <目录> --board v2`（`--board all` 同时构建两种板型，共 6 个 UF2）。

V2 额外的验收项：1.8 V / 3.3 V / 5 V 三种 VREF 下的 SWD 与串口；INT / EXT 两档；nRESET 拉低与释放波形；逻辑分析 8 路的通道顺序（逐路接已知方波）和 50000 点采集；DIR 默认状态下 IO0 / IO1 / IO3 为输出，接线前先刷入对应固件。

## 板卡网络与接线（V1）

| J2 脚号 | 网络 | 调试固件 | 逻辑分析固件 | 示波器固件 |
|---|---|---|---|---|
| 1 | GND | 共地 | 共地 | 共地 |
| 2 | +3V3 | 电源输出 | 电源输出 | 电源输出 |
| 3 | GP20 | SWCLK | D0 | 未用 |
| 4 | +5V | USB 电源输出 | USB 电源输出 | USB 电源输出 |
| 5 | GP21 | SWDIO | D1 | 未用 |
| 6 | GP25 | UART RX | D5 | 未用 |
| 7 | GP22 | 目标 nRESET（可选） | D2 | 未用 |
| 8 | GP26 | 未用 | D6 | ADC0 |
| 9 | GP23 | 未用 | D3 | 未用 |
| 10 | GP27 | 未用 | D7 | ADC1 |
| 11 | GP24 | UART TX | D4 | 未用 |
| 12 | GP28 | 未用 | 保留 | ADC2 |

这里的脚号来自 PCB 焊盘号；请根据实际 J2 的 1 脚标记定位，不以照片方向推断。UART TX 接目标 RX，UART RX 接目标 TX。板上状态 LED 使用 GP0；QSPI Flash 为 GD25Q64（8 MiB），晶振为 12 MHz。RP2040 自身的 SWCLK/SWDIO 网络没有接出；表中 GP20/21 是调试固件产生的目标 SWD。

信号脚直连 RP2040，没有电平转换、输入限幅、分压、运放或抗混叠滤波器。数字输入按 3.3 V 逻辑使用；ADC 仅接 0–3.3 V 且不高于实测参考电压的信号，不接 5 V 或负电压。J2 的 +3V3 / +5V 是电源输出，不能当成 VTref。ADC 数据换算 `volts = raw * vref / 4096`；12 bit 是输出码宽，不代表 12 bit 有效精度。高阻信号源、参考电压纹波和混叠会影响结果，需要前端与校准后才能作为通用示波器使用。

## 安装

1. 在 Agent 的「RP2040 固件」页下载对应 UF2。
2. 断开目标信号线，按住板上 BOOT，再插入 USB。
3. 将 UF2 复制到出现的 `RPI-RP2` 磁盘；板卡自动重新启动。
4. 启动本地 Agent，点击刷新并选择 RP2040。USB 产品名分别为 `LA-RP2040 CMSIS-DAP`、`LA-RP2040 SUMP8 v1`、`LA-RP2040 ADC12 v1`。
5. 按接线表连接目标，在 MCU / 逻辑分析 / 数字示波器页面执行任务。

未知的 `2e8a:000a` 设备不会自动发送探测命令，避免向普通 Pico 串口程序注入 SUMP 指令。逻辑/ADC 必须识别本板固件产品名，执行前还会做二进制握手。Windows 如果无法识别产品名，安装/检查 CDC 驱动和 libusb 枚举后重连。CMSIS-DAP `2e8a:000c` 可被识别，但使用原版固件时须自行核对实际 GPIO，不能套用本板映射。

每次仅连接一个同系列调试器；可以同时连接一个 CH347 和一个 RP2040，在网页选择设备。Agent 会检查设备身份、固件配置、串口和当前会话归属。采集与下载任务串行执行。导出文件保存在本机数据目录；下载令牌只在当前 Agent 进程内有效，服务重启后可从本机目录保留的原始文件恢复。

## 固件源码与构建

`dist/firmware/firmware-sources.tar.gz` 包含完整对应源码、Pico SDK、TinyUSB、FreeRTOS、许可证、板级修改和构建脚本。无需从网络重新拉源码即可编译。`dist/firmware/manifest.json` 记录版本、固定提交与 UF2 SHA-256。

在线构建（Python 3.10+、Git、CMake、Ninja、Arm GNU Toolchain，包含 newlib）：

```bash
python firmware/build.py --work /absolute/path/build-area            # 两种板型，共 6 个 UF2
python firmware/build.py --work /absolute/path/build-area --board v2 # 只构建 V2
```

离线源码包构建：

```bash
tar -xzf dist/firmware/firmware-sources.tar.gz
python firmware-sources/firmware/build.py --work /absolute/path/firmware-sources --output /absolute/path/output
```

工具链版本不同可能产生不同哈希；构建生成 `build-results.json`。本次工具链 GCC 13.2.1，SDK 2.3.0。Flash 容量按 8 MiB，使用通用 SPI `0x03` 二级启动代码以避免依赖特定 Flash 的 Quad Enable 配置。

- `raspberrypi/debugprobe`：固定 `262f9625d75a2bad8d76cc228ee5e21ca3a64d3a`，MIT；CMSIS-DAP 部分保留其许可证。修改 GPIO、产品名与构建版本。
- `dgatf/logic_analyzer_rp2040`：固定 `1b93e38126ca159a57b13c624b816e8e6eee15e9`，GPL-3.0-or-later。改为 GP20 起始 8 通道、GP0 状态灯；修正触发脚偏移与数组边界；去除 200 MHz 超频，改为 100 MHz；固定显式触发类型；关闭 USB CRLF 转换以免损坏二进制样本。
- ADC12：本工程新增 MIT 源码，参考官方 Pico SDK 与 `pico-examples/adc/dma_capture` 的 DMA 采样方式，独立二进制 CDC 协议，无后台调试文字混入数据流。
- `raspberrypi/pico-sdk`：2.3.0，固定 `98a542c1a62fb549ffb5d66a3e5892b06276b670`，保留其 BSD 和组件许可证。

## 验收清单

先用低频、低幅信号验收，再增加速率。需要实测的步骤：

1. 三种 UF2 均能 BOOTSEL 刷写与重新枚举，产品名正确，GP0 状态灯正常。
2. SWD 接已知目标读 ID、读内存、暂停/继续；测试固件烧录与读回校验；UART TX/RX 环回。
3. 逻辑 D0–D7 分别接 GND、3.3 V 及已知方波，核对通道顺序和采样周期；测试边沿/电平触发和未触发超时。
4. ADC 分别接 GND、经万用表测得的已知直流电压和低频正弦，检查原始码、参考电压、Vpp/RMS；逐一检查 ADC0/1/2。
5. 拔线、取消、重连、更换固件后，不应复用过期计划或显示伪造波形。
6. 使用 PulseView 打开 `.sr` / VCD，检查时间轴和通道；CSV 与采集点数及原始码一致。

软件验证覆盖命令参数、SUMP 反向数据还原、分片读取、0x0A/0x0D 保真、ADC FIFO 错误、错误握手、超时/取消、跨设备拒绝、导出格式、UF2 块重组；PTY 模拟器覆盖真实 pyserial 和 HTTP→采集→CSV 下载路径。这些结果不能替代板上 PIO/ADC 时序和电气测试。

## 一手资料

- https://github.com/raspberrypi/debugprobe
- https://www.raspberrypi.com/documentation/microcontrollers/debug-probe.html
- https://github.com/dgatf/logic_analyzer_rp2040
- https://github.com/raspberrypi/pico-examples/tree/master/adc/dma_capture
- https://www.raspberrypi.com/documentation/pico-sdk/hardware.html
- https://sigrok.org/wiki/File_format:Sigrok/v2

## 波形缩放与移动

采集完成后，点击“＋ 放大 / − 缩小”，或在波形上滚动鼠标滚轮缩放时间轴；“窗口”下拉框可直接选择点数，最小显示 32 点。滚轮以鼠标所在位置为中心缩放。

“全部样本”模式下已显示完整记录，时间位置滑杆会禁用并提示先放大。放大后可拖动滑杆或直接拖动波形平移；当前位置和时间范围随之更新。“显示全部”恢复完整记录。单击波形放置 A/B 游标，拖动不会误放游标。

波形获得焦点后，支持 `+ / -` 缩放、左右方向键平移、`Home` 复位。打开同一采集结果时保留缩放、位置与游标；新的采集恢复全景。显示缩放不改变采集参数、原始数据或导出文件。

前端范围计算回归测试：`node --test tests/test_waveform.js`。
